resource "aws_db_instance" "main" {
  identifier          = var.db_identifier
  engine              = "postgres"
  instance_class      = "db.t3.micro"
  allocated_storage   = 20
  username            = var.db_username
  password            = var.db_password
  db_name             = "fraud_detection"
  skip_final_snapshot = true
  apply_immediately   = true
}
