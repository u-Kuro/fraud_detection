-- ADD COLUMN
-- 1. Add null column: ALTER TABLE tab ADD COLUMN col type (Instant <1s) [PG11+ DEFAULT is instant]
-- 2. Update ORM/API to read/write new column (Decoupled Deployment)
-- 3. Backfill existing nulls via background jobs (Interval Batching)
-- 4. Enforce NOT NULL safely: ALTER TABLE tab ADD CONSTRAINT con CHECK (col IS NOT NULL) NOT VALID (Instant <1s)
-- 5. Validate historical data: ALTER TABLE tab VALIDATE CONSTRAINT con (Non-blocking)
-- 6. Make native NOT NULL (PG12+): ALTER TABLE tab ALTER COLUMN col SET NOT NULL (Instant <1s)
-- 7. Cleanup constraint: ALTER TABLE tab DROP CONSTRAINT con (Instant <1s)
--
-- DELETE COLUMN
-- 1. Ignore column in ORM/API so cached `SELECT *` doesn't crash (Decoupled Deployment)
-- 2. Drop column: ALTER TABLE tab DROP COLUMN col (Instant <1s)
--
-- CHANGE COLUMN
-- 1. Add new column: ALTER TABLE tab ADD COLUMN new_col new_type (Instant <1s)
-- 2. Update ORM/API to dual-write to both old and new columns, read from old (Decoupled Deployment)
-- 3. Backfill data from old to new column via background jobs (Interval Batching)
-- 4. Update ORM/API to read/write only from new column (Decoupled Deployment)
-- 5. Enforce NOT NULL safely: ALTER TABLE tab ADD CONSTRAINT con CHECK (new_col IS NOT NULL) NOT VALID (Instant <1s)
-- 6. Validate historical data: ALTER TABLE tab VALIDATE CONSTRAINT con (Non-blocking)
-- 7. Make native NOT NULL (PG12+): ALTER TABLE tab ALTER COLUMN new_col SET NOT NULL (Instant <1s)
-- 8. Ignore old column in ORM/API (Decoupled Deployment)
-- 9. Cleanup: ALTER TABLE tab DROP CONSTRAINT con, DROP COLUMN old_col (Instant <1s)












-- select tablename from pg_catalog.pg_tables
-- where schemaname != 'pg_catalog' and schemaname != 'information_schema';

-- select * from transactions where "Class" = 1;
-- select * from transactions where "Class" = 0;

-- select
--     "Time",
--     "Amount",
--     "Class",
--     row_number() over (Partition by "Class" order by "Amount") "Row",
--     rank() over (partition by "Class" order by "Amount") "Rank",
--     dense_rank() over (partition by "Class" order by "Amount") "Dense_Rank"
-- from transactions order by "Row", "Dense_Rank", "Rank";

-- WITH rank as (
--     select
--         "Class",
--         "Amount",
--         dense_rank() over (partition by "Class" order by "Amount" desc) "Dense_Rank"
--     FROM transactions
-- )
-- select
--     distinct "Class",
--     "Amount"
-- FROM rank
-- WHERE "Dense_Rank" = 2;

-- SELECT * FROM transactions where "Amount" is null;

-- select
--     "Amount",
--     coalesce("Amount", 0) amount_zero_if_null,
--     nullif("Amount", 0) amount_null_if_zero
-- from transactions;

-- SELECT * FROM transactions where "Amount" is not null;

-- select "Class", AVG("Amount") avg_amount, COUNT(*)
-- from transactions
-- where "Time" > 50000
-- group by "Class"
-- having avg("Amount") > 50
-- order by avg_amount desc;

-- WITH fraud_stats AS (
--     SELECT
--         "Class",
--         COUNT(*)       AS total,
--         AVG("Amount")  AS avg_amount,
--         MAX("Amount")  AS max_amount
--     FROM transactions
--     GROUP BY "Class"
-- ),
-- fraud_pct AS (
--     SELECT
--         *,
--         100.0 * total / SUM(total) OVER () AS pct_of_all
--     FROM fraud_stats
-- )
-- SELECT * FROM fraud_pct ORDER BY "Class";


-- CREATE TABLE new_table_name (
--     LIKE old_table_name INCLUDING ALL
-- );

SELECT EXTRACT(EPOCH FROM transaction_timestamp), transaction_timestamp FROM transaction_inferences ORDER BY transaction_timestamp DESC

SELECT COUNT(*) FROM transaction_inferences

SELECT MIN(transaction_timestamp), MAX(transaction_timestamp) FROM transaction_inferences;