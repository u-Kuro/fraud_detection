import logging
from contextlib import asynccontextmanager

import mlflow
from fastapi import FastAPI
from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor

from services.fraud_api.src.modules.inference import FraudClassifier
from services.fraud_api.src.modules.repository.postgres.fraud_inference_repository import (
    FraudInferenceRepository,
)
from services.fraud_api.src.modules.observability import Observability
from services.fraud_api.src.modules.middleware import RequestIdMiddleware
from services.fraud_api.src.modules.environment import environment

from services.fraud_api.src.api.routers import health, inference

Observability(environment).init()
logger = logging.getLogger(__name__)

@asynccontextmanager
async def lifespan(app: FastAPI):
    FastAPIInstrumentor.instrument_app(app)

    try:
        mlflow.set_tracking_uri(environment.MLFLOW_TRACKING_URI)

        app.state.classifier = FraudClassifier(
            model_uri=environment.mlflow_model_uri,
            flavor=environment.mlflow_model_flavor,
        )
        app.state.inference_repository = FraudInferenceRepository()

    except Exception as exc:
        logger.critical(f"Startup failed: {exc}", exc_info=True)
        raise RuntimeError("Startup failed") from exc

    yield

    logger.info("Shutting down.")


app = FastAPI(
    title="Fraud Detection API",
    description="Serves models from MLflow Model Registry.",
    version="1.0.0",
    lifespan=lifespan,
)

# Middlewares
app.add_middleware(RequestIdMiddleware)

# Routers
app.include_router(health.router)
app.include_router(inference.router)


@app.get("/", include_in_schema=False)
def root():
    return {"message": "Fraud Detection API — visit /docs"}
