import logging
from typing import Any

import mlflow
import pandas as pd
from mlflow import MlflowClient
from services.fraud_api.src.modules.observability.metrics import observe
from services.fraud_api.src.modules.schemas import (
    DeployedModel,
    MlflowModelFeatures,
    MlflowModelFlavor,
    MlflowModelUri,
    ClassificationRequest,
    TransactionClassification,
)

logger = logging.getLogger(__name__)

class FraudClassifier:
    def __init__(self, model_uri: MlflowModelUri, flavor: MlflowModelFlavor):
        self.model_uri = model_uri.model_uri
        mlflow_flavors = {"sklearn": mlflow.sklearn, "pyfunc": mlflow.pyfunc}
        self.flavor = flavor.flavor
        self.model: Any = mlflow_flavors[self.flavor].load_model(
            model_uri=self.model_uri
        )
        model_info = self._get_model_info()
        self.model_name = model_info.model_name
        self.model_version = model_info.model_version
        logger.info(f"Model loaded: {model_uri} → version {self.model_version}")

    @observe
    def classify(self, request: ClassificationRequest) -> TransactionClassification:
        features = request.model_dump(include=MlflowModelFeatures.model_fields.keys())

        features_df = pd.DataFrame([features])
        features_df["transaction_timestamp"] = features_df[
            "transaction_timestamp"
        ].apply(lambda x: int(x.timestamp()))

        prediction = int(self.model.classify(features_df)[0])
        if self.flavor == "sklearn":
            fraud_probability = self.model.predict_proba(features_df)[0][1]
        else:
            fraud_probability = self.model.classify(
                data=features_df, params={"probabilities": True}
            )[0][1]

        return TransactionClassification(
            **request.model_dump(),
            is_fraud=None,
            is_fraud_probability=float(fraud_probability),
            is_fraud_prediction=prediction == 1,
            model_name=self.model_name,
            model_version=self.model_version,
        )

    def _get_model_info(self) -> DeployedModel:
        try:
            client = MlflowClient()
            model_path = self.model_uri.replace("models:/", "")

            # Handle Alias strings ("model@production")
            if "@" in model_path:
                model_name, model_alias = model_path.split("@")
                model_version = client.get_model_version_by_alias(
                    name=model_name, alias=model_alias
                )
                return DeployedModel(
                    model_name=model_name, model_version=int(model_version.version)
                )

            # Handle Version strings ("model/5")
            elif "/" in model_path:
                model_name, model_version = model_path.split("/")

                # If it's already a digit string (e.g., "5"), just use it directly
                if model_version.isdigit():
                    return DeployedModel(
                        model_name=model_name, model_version=int(model_version)
                    )

            raise ValueError(f"Invalid model URI format: {self.model_uri}")
        except Exception as exception:
            logger.warning(f"Could not resolve version: {exception}")
            raise exception
