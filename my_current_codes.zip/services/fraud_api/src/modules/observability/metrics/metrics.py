import inspect
import threading
import time
from functools import wraps
from typing import Any

from opentelemetry import metrics, trace
from opentelemetry.trace import SpanKind, StatusCode

# ── Module-level caches, populated lazily on first use ──────────────────────
_meters: dict[str, Any] = {}
_tracers: dict[str, Any] = {}
_instruments: dict[str, Any] = {}
_lock = threading.Lock()  # guards all three caches against duplicate creation


def get_meter(module_name: str):
    if module_name not in _meters:            # fast path
        with _lock:
            if module_name not in _meters:    # double-checked
                _meters[module_name] = metrics.get_meter(module_name)
    return _meters[module_name]


def get_tracer(module_name: str):
    if module_name not in _tracers:
        with _lock:
            if module_name not in _tracers:
                _tracers[module_name] = trace.get_tracer(module_name)
    return _tracers[module_name]


def _get_instruments(func_key: str, module_name: str, display_name: str) -> dict:
    if func_key not in _instruments:
        with _lock:
            if func_key not in _instruments:
                meter = get_meter(module_name)
                _instruments[func_key] = {
                    # RED — Duration  (latency percentiles; exemplars auto-attached when
                    #                  inside an active span → links to Tempo in Grafana)
                    "duration": meter.create_histogram(
                        name=f"{func_key}.duration",
                        description=f"Duration of {display_name} executions",
                        unit="s",
                    ),
                    # RED — Rate  (rate() in PromQL gives requests/sec)
                    "calls": meter.create_counter(
                        name=f"{func_key}.calls",
                        description=f"Total calls to {display_name}",
                        unit="{call}",
                    ),
                    # RED — Errors  (rate() gives error rate; error.type label for breakdown)
                    "errors": meter.create_counter(
                        name=f"{func_key}.errors",
                        description=f"Total errors raised by {display_name}",
                        unit="{error}",
                    ),
                }
    return _instruments[func_key]


def _static_span_attrs(func) -> dict:
    """
    Compute OTel semantic code.* span attributes once at decoration time,
    not on every call. filepath/lineno are best-effort.
    """
    attrs: dict[str, Any] = {
        "code.function": func.__name__,
        # code.namespace = enclosing class for methods, module for plain functions
        "code.namespace": (
            func.__qualname__.rsplit(".", 1)[0]
            if "." in func.__qualname__
            else func.__module__
        ),
    }
    try:
        attrs["code.filepath"] = inspect.getfile(func)
        _, lineno = inspect.getsourcelines(func)
        attrs["code.lineno"] = lineno
    except (TypeError, OSError):
        pass
    return attrs


def observe(func):
    """
    Decorator that instruments sync and async functions with LGTM-ready telemetry.

    Per invocation
    ──────────────
    Tracing  → INTERNAL span with semantic code.* attributes, StatusCode,
                and a span exception event (type + stacktrace, escaped=True)

    Metrics  → duration histogram  — p50/p95/p99; histogram exemplars carry
                                      trace_id/span_id → metric→trace links in Grafana
                calls counter      — RED Rate:  rate(calls[1m])
                errors counter     — RED Error: rate(errors[1m])
                                      labelled with error.type for breakdown by exception

    Prerequisite for metric→trace exemplars
    ────────────────────────────────────────
    1. MeterProvider must be configured with TraceBasedExemplarFilter (see observability.py)
    2. Prometheus exporter must have enable_open_metrics: true  (see otelcol-config.yaml)
    3. Prometheus must be started with --enable-feature=exemplar-storage
       (or feature_flags: [exemplar-storage] in prometheus.yml)
    """
    qual = func.__qualname__
    mod = func.__module__
    key = f"{mod}.{qual}"
    span_attrs = _static_span_attrs(func)  # computed once

    if inspect.iscoroutinefunction(func):
        @wraps(func)
        async def async_wrapper(*args, **kwargs):
            inst = _get_instruments(key, mod, qual)
            labels = {"function": qual, "module": mod}
            inst["calls"].add(1, attributes=labels)
            t0 = time.perf_counter()

            with get_tracer(mod).start_as_current_span(
                qual, kind=SpanKind.INTERNAL, attributes=span_attrs
            ) as span:
                try:
                    result = await func(*args, **kwargs)
                    span.set_status(StatusCode.OK)
                    return result
                except Exception as exc:
                    span.set_status(StatusCode.ERROR, str(exc))
                    # escaped=True → marks that the exception propagated out of the span
                    span.record_exception(exc, escaped=True)
                    inst["errors"].add(
                        1,
                        attributes={**labels, "error.type": type(exc).__qualname__},
                    )
                    raise
                finally:
                    # Record inside the span so the SDK can attach exemplars automatically
                    inst["duration"].record(time.perf_counter() - t0, attributes=labels)

        return async_wrapper

    @wraps(func)
    def sync_wrapper(*args, **kwargs):
        inst = _get_instruments(key, mod, qual)
        labels = {"function": qual, "module": mod}
        inst["calls"].add(1, attributes=labels)
        t0 = time.perf_counter()

        with get_tracer(mod).start_as_current_span(
            qual, kind=SpanKind.INTERNAL, attributes=span_attrs
        ) as span:
            try:
                result = func(*args, **kwargs)
                span.set_status(StatusCode.OK)
                return result
            except Exception as exc:
                span.set_status(StatusCode.ERROR, str(exc))
                span.record_exception(exc, escaped=True)
                inst["errors"].add(
                    1,
                    attributes={**labels, "error.type": type(exc).__qualname__},
                )
                raise
            finally:
                inst["duration"].record(time.perf_counter() - t0, attributes=labels)

    return sync_wrapper
