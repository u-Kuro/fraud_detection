from fastapi import APIRouter, HTTPException, Request
from sqlalchemy import text

from services.fraud_api.src.modules.schemas import HealthResponse

router = APIRouter(tags=["ops"])

@router.get("/health/live")
def health_live(request: Request) -> HealthResponse:
    is_loaded = hasattr(request.app.state, "classifier") and request.app.state.classifier is not None
    return HealthResponse(status="live", model_loaded=is_loaded)

@router.get("/health/ready")
def health_ready(request: Request) -> HealthResponse:
    classifier = getattr(request.app.state, "classifier", None)
    inference_repository = getattr(request.app.state, "inference_repository", None)

    if classifier is None:
        raise HTTPException(status_code=503, detail="Model not loaded.")

    if inference_repository is not None:
        try:
            with inference_repository.engine.connect() as conn:
                conn.execute(text("SELECT 1"))
        except Exception as exc:
            raise HTTPException(status_code=503, detail=f"DB not ready: {exc}")

    return HealthResponse(status="ready", model_loaded=True)

@router.get("/health", include_in_schema=False)
def health_check(request: Request):
    return health_ready(request)