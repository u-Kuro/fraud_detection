import logging
from fastapi import APIRouter, HTTPException, Request

from services.fraud_api.src.modules.inference import FraudClassifier
from services.fraud_api.src.modules.repository.postgres.fraud_inference_repository import FraudInferenceRepository
from services.fraud_api.src.modules.schemas import ClassificationRequest, ClassificationResponse

logger = logging.getLogger(__name__)
router = APIRouter(tags=["inference"])

@router.post("/classify")
def classify(request: Request, payload: ClassificationRequest) -> ClassificationResponse:
    classifier: FraudClassifier | None = getattr(request.app.state, "classifier", None)
    if classifier is None:
        raise HTTPException(status_code=503, detail="Model failed to load.")

    inference_repository: FraudInferenceRepository | None = getattr(request.app.state, "inference_repository", None)
    if inference_repository is None:
        raise HTTPException(status_code=503, detail="Inference repository failed to load.")

    try:
        transaction_inference = classifier.classify(request=payload)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=f"Bad input: {exc}")
    except Exception as exc:
        logger.error(f"Prediction error: {exc}", exc_info=True)
        raise HTTPException(status_code=500, detail="Inference error.")

    if inference_repository is not None:
        inference_repository.insert(transaction_inference)

    return ClassificationResponse(
        **transaction_inference.model_dump(include=ClassificationResponse.model_fields.keys())
    )